package inge2.dataflow.targets;

public class Target1 {
    public void entryPoint() {
        Target1 x = new Target1();
    }
}
