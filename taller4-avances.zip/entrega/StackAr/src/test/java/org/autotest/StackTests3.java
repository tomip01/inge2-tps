package org.autotest;

import static org.junit.jupiter.api.Assertions.*;

public class StackTests3 extends MutationAnalysisRunner {
    @Override
    protected boolean useVerboseMode() {
        return false;
    }

    // Tests de StackTests3

    public void testSizeIncreasesByOne() throws Exception {
        Stack stack = createStack();
        assertEquals(0, stack.size());
        stack.push(42);
        assertEquals(1, stack.size());
    }

    public void testDefaultConstructor() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
    }

    public void testConstructorWithSpecifiedCapacity() throws Exception {
        Stack stack = createStack(5);
    }

    public void testConstructorWithNegativeCapacity() {
        assertThrows(IllegalArgumentException.class, () -> {
            Stack stack = createStack(-1);
        });
    }

    public void testIsEmptyMethod() throws Exception {
        Stack stack = createStack();
        assertTrue(stack.isEmpty());
        stack.push(42);
        assertFalse(stack.isEmpty());
        stack.pop();
        assertTrue(stack.isEmpty());
    }

    public void testIsFullMethod() throws Exception {
        Stack stack = createStack(1);
        assertFalse(stack.isFull());
        stack.push(42);
        assertTrue(stack.isFull());
        stack.pop();
        assertFalse(stack.isFull());
    }

    public void testToStringMethod() throws Exception {
        Stack stack = createStack(2);
        assertEquals("[]", stack.toString());
        stack.push(42);
        assertEquals("[42]", stack.toString());
        stack.push(43);
        assertEquals("[42,43]", stack.toString());
    }

    public void testNotNullablePop() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertEquals("42", stack.pop().toString());
    }

    public void testNotNullableTop() throws Exception {
        Stack stack = createStack(1);
        stack.push(42);
        assertEquals("42", stack.top().toString());
    }

    public void testNotFullAfterPush() throws Exception {
        Stack stack1 = createStack(2);
        stack1.push(41);
        Stack stack2 = createStack(2);
        stack2.push("42");

        assertNotEquals(stack1.hashCode(), stack2.hashCode());
    }

    public void testCapacityZero() throws Exception {
        Stack stack1 = createStack(0);
    }

    public void testCapacityZeroAndTop() throws Exception {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack1 = createStack(0);
            stack1.top();
        });
    }

    public void testEqualsItself() throws Exception {
        Stack stack1 = createStack(0);
        assertTrue(stack1.equals(stack1));
    }

    public void testNotNullShouldNotEqualsNull() throws Exception {
        Stack stack1 = createStack(0);
        Stack stack2 = createStack(0);
        assertTrue(stack1.equals(stack2));
    }

    public void testStackNotNullShouldNotBeEqual() throws Exception {
        Stack stack1 = createStack(0);
        assertFalse(stack1.equals(null));
    }

    public void testDifferentElementsShouldNotBeEqual() throws Exception {
        Stack stack1 = createStack(1);
        Stack stack2 = createStack(1);
        stack2.push(42);
        assertFalse(stack1.equals(stack2));
    }

    public void testDifferentClassShouldNotBeEqual() throws Exception {
        Stack stack1 = createStack(1);
        assertFalse(stack1.equals(3));
    }

    public void testCapacityZeroAndPop() throws Exception {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack1 = createStack(1);
            stack1.pop();
        });
    }

    public void testSameElementsShouldBeEqual() throws Exception {
        Stack stack1 = createStack(1);
        Stack stack2 = createStack(1);
        stack1.push(42);
        stack2.push(43);
        assertFalse(stack1.equals(stack2));
    }

    public void testCapacityFullAndPush() throws Exception {
        assertThrows(IllegalStateException.class, () -> {
            Stack stack1 = createStack(1);
            stack1.push(1);
            stack1.push(1);
        });
    }

    public void testDifferentElementsShouldNotBeEqualAfterPop() throws Exception {
        Stack stack1 = createStack(1);
        Stack stack2 = createStack(1);
        stack1.push(42);
        stack2.push(42);
        stack2.pop();
        assertFalse(stack1.equals(stack2));
    }

    public void testDefaultCapacityShouldBeTen() throws Exception {
        Stack stack1 = createStack();
        stack1.push(1);
        stack1.push(1);
    }
}
